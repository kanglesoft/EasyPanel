/*
   +----------------------------------------------------------------------+
   | PHP Version 7                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | http://www.php.net/license/3_01.txt                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " './configure'  '--build=x86_64-redhat-linux-gnu' '--host=x86_64-redhat-linux-gnu' '--program-prefix=' '--disable-dependency-tracking' '--prefix=/opt/remi/php74/root/usr' '--exec-prefix=/opt/remi/php74/root/usr' '--bindir=/opt/remi/php74/root/usr/bin' '--sbindir=/opt/remi/php74/root/usr/sbin' '--sysconfdir=/etc/opt/remi/php74' '--datadir=/opt/remi/php74/root/usr/share' '--includedir=/opt/remi/php74/root/usr/include' '--libdir=/opt/remi/php74/root/usr/lib64' '--libexecdir=/opt/remi/php74/root/usr/libexec' '--localstatedir=/var/opt/remi/php74' '--sharedstatedir=/var/opt/remi/php74/lib' '--mandir=/opt/remi/php74/root/usr/share/man' '--infodir=/opt/remi/php74/root/usr/share/info' '--enable-rtld-now' '--cache-file=../config.cache' '--with-libdir=lib64' '--with-config-file-path=/etc/opt/remi/php74' '--with-config-file-scan-dir=/etc/opt/remi/php74/php.d' '--disable-debug' '--with-pic' '--disable-rpath' '--without-pear' '--with-exec-dir=/opt/remi/php74/root/usr/bin' '--without-gdbm' '--with-openssl' '--with-system-ciphers' '--with-zlib' '--with-layout=GNU' '--with-kerberos' '--with-libxml' '--with-system-tzdata' '--with-mhash' '--without-password-argon2' '--enable-dtrace' '--libdir=/opt/remi/php74/root/usr/lib64/php' '--enable-pcntl' '--enable-opcache' '--enable-opcache-file' '--enable-phpdbg' '--with-imap=shared' '--with-imap-ssl' '--enable-mbstring=shared' '--enable-mbregex' '--enable-gd=shared' '--with-external-gd' '--with-gmp=shared' '--enable-calendar=shared' '--enable-bcmath=shared' '--with-bz2=shared' '--enable-ctype=shared' '--enable-dba=shared' '--with-db4=/usr' '--with-tcadb=/usr' '--with-lmdb=/usr' '--enable-exif=shared' '--enable-ftp=shared' '--with-gettext=shared' '--with-iconv=shared' '--enable-sockets=shared' '--enable-tokenizer=shared' '--with-xmlrpc=shared' '--with-ldap=shared' '--with-ldap-sasl' '--enable-mysqlnd=shared' '--with-mysqli=shared,mysqlnd' '--with-mysql-sock=/var/lib/mysql/mysql.sock' '--with-oci8=shared,instantclient,/usr/lib/oracle/21/client64/lib,21.13' '--with-pdo-oci=shared,instantclient,/usr/lib/oracle/21/client64/lib,21.13' '--with-pdo-firebird=shared' '--enable-dom=shared' '--with-pgsql=shared' '--enable-simplexml=shared' '--enable-xml=shared' '--with-snmp=shared,/usr' '--enable-soap=shared' '--with-xsl=shared,/usr' '--enable-xmlreader=shared' '--enable-xmlwriter=shared' '--with-curl=shared' '--enable-pdo=shared' '--with-pdo-odbc=shared,unixODBC,/usr' '--with-pdo-mysql=shared,mysqlnd' '--with-pdo-pgsql=shared,/usr' '--with-pdo-sqlite=shared' '--with-sqlite3=shared' '--enable-json=shared' '--without-readline' '--with-libedit' '--with-pspell=shared' '--enable-phar=shared' '--with-tidy=shared,/usr' '--with-pdo-dblib=shared,/usr' '--enable-sysvmsg=shared' '--enable-sysvshm=shared' '--enable-sysvsem=shared' '--enable-shmop=shared' '--enable-posix=shared' '--with-unixODBC=shared,/usr' '--enable-intl=shared' '--with-enchant=shared' '--enable-fileinfo=shared' '--with-ffi=shared' '--with-sodium=shared' 'build_alias=x86_64-redhat-linux-gnu' 'host_alias=x86_64-redhat-linux-gnu' 'PKG_CONFIG_PATH=/opt/rh/devtoolset-8/root/usr/lib64/pkgconfig::/opt/remi/php74/root/usr/lib64/pkgconfig:/opt/remi/php74/root/usr/share/pkgconfig' 'CFLAGS=-O2 -g -pipe -Wall -Wp,-D_FORTIFY_SOURCE=2 -fexceptions -fstack-protector-strong --param=ssp-buffer-size=4 -grecord-gcc-switches -specs=/usr/lib/rpm/redhat/redhat-hardened-cc1 -m64 -mtune=generic -fno-strict-aliasing -Wno-pointer-sign' 'CXXFLAGS=-O2 -g -pipe -Wall -Wp,-D_FORTIFY_SOURCE=2 -fexceptions -fstack-protector-strong --param=ssp-buffer-size=4 -grecord-gcc-switches -specs=/usr/lib/rpm/redhat/redhat-hardened-cc1 -m64 -mtune=generic'"
#define PHP_ODBC_CFLAGS	"-I/usr/include"
#define PHP_ODBC_LFLAGS		"-L/usr/lib64"
#define PHP_ODBC_LIBS		"-lodbc"
#define PHP_ODBC_TYPE		"unixODBC"
#define PHP_OCI8_DIR			"/usr/lib/oracle/21/client64/lib"
#define PHP_OCI8_ORACLE_VERSION		"21.1"
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         "/opt/remi/php74/root/usr/share/pear"
#define PHP_INCLUDE_PATH	".:/opt/remi/php74/root/usr/share/pear:/opt/remi/php74/root/usr/share/php:/usr/share/pear:/usr/share/php"
#define PHP_EXTENSION_DIR       "/opt/remi/php74/root/usr/lib64/php/modules"
#define PHP_PREFIX              "/opt/remi/php74/root/usr"
#define PHP_BINDIR              "/opt/remi/php74/root/usr/bin"
#define PHP_SBINDIR             "/opt/remi/php74/root/usr/sbin"
#define PHP_MANDIR              "/opt/remi/php74/root/usr/share/man"
#define PHP_LIBDIR              "/opt/remi/php74/root/usr/lib64/php"
#define PHP_DATADIR             "/opt/remi/php74/root/usr/share"
#define PHP_SYSCONFDIR          "/etc/opt/remi/php74"
#define PHP_LOCALSTATEDIR       "/var/opt/remi/php74"
#define PHP_CONFIG_FILE_PATH    "/etc/opt/remi/php74"
#define PHP_CONFIG_FILE_SCAN_DIR    "/etc/opt/remi/php74/php.d"
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
